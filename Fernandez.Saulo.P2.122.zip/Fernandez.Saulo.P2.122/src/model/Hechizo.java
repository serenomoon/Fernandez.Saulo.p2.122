package model;

import java.io.Serializable;
import java.util.Objects;

public class Hechizo implements Comparable<Hechizo>, CSVSerializable, Serializable{
    
    private int id;
    private String nombre;
    private String creador;
    private TipoHechizo tipo;

    public Hechizo(int id, String nombre, String creador, TipoHechizo tipo) {
        this.id = id;
        this.nombre = nombre;
        this.creador = creador;
        this.tipo = tipo;
    }

    public int getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public String getCreador() {
        return creador;
    }

    public TipoHechizo getTipo() {
        return tipo;
    }
    
    @Override
    public int compareTo(Hechizo h) {
        return Integer.compare(this.id, h.getId());
    }

    @Override
    public String toCSV() {
        return id + "," + nombre + "," + creador + "," + tipo;
    }
    
    @Override
    public boolean equals(Object o){
        if(this == o) return true;
        if(o == null || o.getClass() != this.getClass()) return false;
        
        Hechizo h = (Hechizo) o;
        
        return h.getNombre().equals(this.nombre) && h.getId() == this.id && h.getCreador().equals(this.creador) && h.getTipo().equals(this.tipo);
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 37 * hash + this.id;
        hash = 37 * hash + Objects.hashCode(this.nombre);
        hash = 37 * hash + Objects.hashCode(this.creador);
        hash = 37 * hash + Objects.hashCode(this.tipo);
        return hash;
    }

    @Override
    public String toString() {
        return "Hechizo{" + "id=" + id + ", nombre=" + nombre + ", creador=" + creador + ", tipo=" + tipo + '}';
    }
    
    public static Hechizo fromCSV(String linea){
        Hechizo toReturn = null;
        String[] partes = linea.split(",");
        
        if(partes.length == 4){
            int idNuevo = Integer.parseInt(partes[0]);
            String nombreNuevo = partes[1];
            String creadorNuevo = partes[2];
            TipoHechizo tipoNuevo = TipoHechizo.valueOf(partes[3]);
            toReturn = new Hechizo(idNuevo, nombreNuevo, creadorNuevo, tipoNuevo);
        }
        
        return toReturn;
    }
    
    public static String toCSVHeader(){
        return "id,nombre,creador,tipo\n";
    }
    
}
