package model;

interface CSVSerializable {
    
    String toCSV();
    
}
