package model;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;
import java.util.function.Consumer;
import java.util.function.Predicate;

public class LibroDeHechizos<T extends CSVSerializable> {

    private List<T> listaHechizos = new ArrayList();

    private boolean validarPorIndice(int indice) {
        boolean toReturn = false;
        if (indice > listaHechizos.size() || indice < 0) {
            toReturn = false;
        }
        return toReturn;
    }

    ;
     
     public void agregar(T item) {
        listaHechizos.add(Objects.requireNonNull(item));
    }

    public void eliminar(int indice) {
        if (validarPorIndice(indice)) {
            listaHechizos.remove(indice);
        }
    }

    public T obtenerElemento(int indice) {
        if (validarPorIndice(indice)) {
            return listaHechizos.get(indice);
        } else {
            throw new IndexOutOfBoundsException();
        }
    }

    public List<T> filtrar(Predicate<? super T> criterio) {
        List<T> nuevaLista = new ArrayList<>();

        for (T t : listaHechizos) {
            if (criterio.test(t)) {
                nuevaLista.add(t);
            }
        }
        return nuevaLista;
    }

    public void ordenar(Comparator<? super T> criterio) {
        listaHechizos.sort(criterio);
    }

    public void guardarEnCSV(String path) throws IOException {
        persistence.PersistenciaHechizos.guardarHechizosCSV((List<? extends Hechizo>) listaHechizos, path);
    }

    public List<Hechizo> cargarDesdeCSV(String path) throws IOException {
        listaHechizos = (List<T>) persistence.PersistenciaHechizos.cargarHechizosCSV(path);
        return (List<Hechizo>) listaHechizos;
    }

    public void guardarEnArchivo(String path) throws IOException {
        persistence.PersistenciaHechizos.serializarHechizos((List<? extends Hechizo>) listaHechizos, path);
    }

    public List<Hechizo> cargarDesdeArchivo(String path) throws IOException, ClassNotFoundException {
        listaHechizos = (List<T>) persistence.PersistenciaHechizos.deserializarHechizos(path);
        return (List<Hechizo>) listaHechizos;
    }

    public void paraCadaElemento(Consumer<? super T> accion) {
        for (T hechizo : listaHechizos) {
            accion.accept(hechizo);
        }
    }

}
