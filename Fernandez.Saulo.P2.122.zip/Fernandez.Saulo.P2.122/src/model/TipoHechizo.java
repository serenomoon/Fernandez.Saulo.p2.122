package model;

public enum TipoHechizo {

    ATAQUE,
    DEFENSA,
    UTILIDAD,
    OSCURO,
    CURACION,
    ENCANTAMIENTO;

}
