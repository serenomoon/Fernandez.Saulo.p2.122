package fernandez.saulo.p2.pkg122;

import config.RutasArchivos;
import java.io.IOException;
import model.Hechizo;
import model.LibroDeHechizos;
import model.TipoHechizo;

public class FernandezSauloP2122 {

    public static void main(String[] args) {

        try {
            LibroDeHechizos<Hechizo> libro = new LibroDeHechizos<>();
            libro.agregar(new Hechizo(1, "Expelliarmus", "Flitwick", TipoHechizo.DEFENSA));
            libro.agregar(new Hechizo(2, "Alohomora", "Desconocido", TipoHechizo.UTILIDAD));
            libro.agregar(new Hechizo(3, "Sectumsempra", "Severus Snape", TipoHechizo.OSCURO));
            libro.agregar(new Hechizo(4, "Lumos", "Desconocido", TipoHechizo.ENCANTAMIENTO));
            libro.agregar(new Hechizo(5, "Vulnera Sanentur", "Snape", TipoHechizo.CURACION));

            // Mostrar todos los hechizos
            System.out.println("Hechizos:");
            libro.paraCadaElemento(p -> System.out.println(p));

            // Filtrar por tipo DEFENSA
            System.out.println("\nHechizos de tipo DEFENSA:");
            libro.filtrar(p -> p.getTipo() == TipoHechizo.DEFENSA).forEach(System.out::println);

            // Filtrar por nombre que contenga "lumos"
            System.out.println("\nHechizos que contienen 'lumos':");
            libro.filtrar(p -> p.getNombre().contains("Lumos")).forEach(System.out::println);

            // Ordenar hechizos por ID (orden natural)
            System.out.println("\nHechizos ordenados por ID:");
            libro.ordenar(null);
            libro.paraCadaElemento(p -> System.out.println(p));

            // Ordenar hechizos por nombre
            System.out.println("\nHechizos ordenados por nombre:");
            libro.ordenar((p1,p2) -> p1.getNombre().compareTo(p2.getNombre()));
            libro.paraCadaElemento(p -> System.out.println(p));

            // Guardar en archivo binario
            libro.guardarEnArchivo("src/data/hechizos.dat");

            // Cargar desde archivo binario
            LibroDeHechizos<Hechizo> libroCargado = new LibroDeHechizos<>();
            libroCargado.cargarDesdeArchivo("src/data/hechizos.dat");
            System.out.println("\nHechizos cargados desde archivo binario:");
            libroCargado.paraCadaElemento(p -> System.out.println(p));

            // Guardar en archivo CSV
            libro.guardarEnCSV("src/data/hechizos.csv");

            // Cargar desde archivo CSV
            libroCargado.cargarDesdeCSV("src/data/hechizos.csv");
            System.out.println("\nHechizos cargados desde archivo CSV:");
            libroCargado.paraCadaElemento(p -> System.out.println(p));

        } catch (IOException | ClassNotFoundException e) {
            System.err.println("Error: " + e.getMessage());
        }
    }
}


